class Employee:
    id=101;
    name="Pradeep Chinchole";
    salary=12000.00;

    def display(self):
        print(self.id,self.name,self.salary);

        
employee=Employee();
employee.display();
