import abc;
class Instrument(metaclass=abc.ABCMeta):
     @abc.abstractmethod
     def play(self):
         ...


class Flute(Instrument):
     def play(self):
         print("Flute is playing toot toot toot");

class Guitar(Instrument):
     def play(self):
         print("Guitar is playing tin tin tin");

class Piano(Instrument):
     def play(self):
         print("Piano is playing tan tan tan");
         
f=Flute();
p=Piano();
g=Guitar();

f.play();
p.play();
g.play();




