class Employee:
     def __init__(self,id=101,name="Pradeep",salary=12000.00):
         self.id=id;
         self.name=name;
         self.salary=salary;
         print("Employee Created..");
     def __del__(self):
         print("Employee Destroyed");   
         
     def display(self):
        print(self.id,self.name,self.salary);
        

def start():
    employee1=Employee();
    employee1.display();
    employee2=Employee(102,"Sachin Tendulkar",34000.00);
    employee2.display();

start();

