def testSpeed(speed):
    try:
        a=100/speed; 
        print('Speed ', a);
    except(e):
        print('ERROR:',e);  

testSpeed(100);
testSpeed(10);




