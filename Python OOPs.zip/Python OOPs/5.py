def display(*name):
    print(name);

display();
display(10);
display(10,20);
display(10,20,30);

