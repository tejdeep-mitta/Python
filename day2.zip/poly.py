# Polymorphism
import abc; #Abstract Base Classes

class Animal(metaclass=abc.ABCMeta):
    @abc.abstractmethod #decorator
    def makeNoise(self):
       ...

class Dog(Animal):
    def makeNoise(self):
        print("Dog is making Noise :bow bow bow....");

class Cat(Animal):
    def makeNoise(self):
        print("Cat is making Noise :miaw miaw miaw...");

class Horse(Animal):
    def makeNoise(self):
        print("Horse is making Noise :khi khi khi...");


animal=Animal(); ## gives error beacuase it is abstract class 


animals=[Dog(),Cat(),Horse(),Dog(),Cat(),Horse()];


def processAnimalNoise(animal):
    print("animal :",type(animal)); 
    animal.makeNoise();

print("Processing Animal Noise....");
for animal in animals:
    processAnimalNoise(animal);
    

    
    





