#deifine Employee Class

class Employee:

    def __init__(self,id=212,name="EMP_NAME",salary=0.00,department="TSG"):
           self.id=id;
           self.name=name;
           self.salary=salary;
           self.department=department;
           print("Employee Created......");

    def __del__(self):
          print("Employee  Destroyed...");

    def showEmpDetails(self):
        print("Id         :",self.id);
        print("Name       :",self.name);
        print("Salary     :",self.salary);
        print("Department :",self.department);


def start():
    print("Inside Start Block ...")
    employee=Employee(101,"SACHIN",34000,"TRAINING");#execute constructor
    employee.showEmpDetails();
    print("=================================")
    employee1=Employee();
    employee1.showEmpDetails();
    print("Existing start block");

start();



        
