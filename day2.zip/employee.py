#deifine Employee Class

class Employee:
    id=101;
    name="Pradep Chinchole";
    salary=12000.55;
    department="Training";

    def showEmpDetails(self):
        print("Id         :",self.id);
        print("Name       :",self.name);
        print("Salary     :",self.salary);
        print("Department :",self.department);

employee=Employee();
employee.showEmpDetails();


        
