#Program to display even odd prime and palindrome numbers fro array

# Function to check number is even or not
def isEven(n):
    return n%2==0;

# Function to check number is odd or not
def isOdd(n):
    return n%2!=0;

# Function to check number is palindrome or not
def isPalindrome(n):
        temp=n;
        rev=0;
        while(n>0):
            dig=n%10;
            rev=rev*10+dig;
            n=n//10;
        return temp==rev;  

# Function to check number is prime or not
def isPrime(n):
        k=0;
        for i in range(2,n+1):
            if(n%i==0):
                k=k+1; 
        return k==1;  


array=[11,21,33,44,5,36,7,8,9,121];

choice=0;

while choice<5:
    print("===========================");
    
    print("Array elements:",array);
    print("1.Display Even Numbers");
    print("2.Display Odd Numbers");
    print("3.Display Prime Numbers");
    print("4.Display Palindrome Numbers");
    print("5.Exit");
    print("===========================");
    choice=int(input("Enter choice :"))
    

    if choice==1:
        print("Even elements from array :");
        for element in array:
            if isEven(element):
                print(element);
    if choice==2:
        print("Odd elements from array :");
        for e in array:
            if isOdd(e):
                print(e);
    if choice==3:
        print("Prime elements from array :");
        for e in array:
            if isPrime(e):
                print(e);
    if choice==4:
        print("Palindrome elements from array :");
        for e in array:
            if isPalindrome(e):
                print(e);




