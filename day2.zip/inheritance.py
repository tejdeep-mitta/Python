#deifine Employee Class

#Parent class
class Employee:
     def __init__(self,id=101,name="Pradeep"):
         self.id=id;
         self.name=name;
         print("Employee constructor..")

     def showDetails(self):
         print("Employee :",self.id,self.name);


class Manager(Employee):
    pass

class Accountant(Employee):
    pass

class Programmer(Employee):
    pass


e=Employee();
e.showDetails();

m=Manager(345,"SACHIN");
p=Programmer(567,"Pradeep");
a=Accountant(3245,"SANJAY");

print("Manager")

m.showDetails();
print("Programmer")
p.showDetails();
print("Accountant")
a.showDetails();









         



 


        
