#Iterators & Generators

#We use for statement for looping over a list.
for i in [1, 2, 3, 4]:
   print(i),
print("===============");

#If we use it with a string, it loops over its characters.
for c in "python":
   print(c);
print("===============");


#If we use it with a dictionary, it loops over its keys.
for k in {"x": 1, "y": 2}:
    print(k);



print("===============");
#If we use it with a file, it loops over lines of the file.
for line in open("12.py"):
     print(line);

#There are many functions which consume these iterables.
print(",".join(["a", "b", "c"]));

print(",".join({"x": 1, "y": 2}));

print(list("Python"));

print(list({"x": 1, "y": 2}));


#The built-in function iter takes an iterable object and returns an iterator.

x=iter([12,34,566]);

print(x.__next__());
print(x.__next__());
print(x.__next__());
print(x.__next__());























