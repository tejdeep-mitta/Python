#deifine Employee Class

class Employee:
         id=101; #public
         _name="Pradeep"; #protected
         __salary=45000;#private 
         
         
         def showDetails(self):
             print("Employee :",self.id,self._name,self.__salary);

e=Employee();
print("Id ",e.id);
print("Name ",e._name);
#print("Salary ",e.__salary); # will get because salary is private
e.showDetails();





 


        
