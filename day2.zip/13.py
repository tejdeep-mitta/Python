# range function

print("range(1,10):",list(range(1,10)));
print("range(4,10):",list(range(4,10)));




