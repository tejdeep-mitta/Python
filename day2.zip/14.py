"""
try:
   fh = open("welcome.txt", "r")
   fh.write("This is my test file for exception handling!!")
except IOError():
   print("Error: can\'t find file or read data",e);
else:
   print("Written content in the file successfully");
   fh.close()
"""   


try:
   x = int(input("Please enter a number: "));
   print("You have entered correct number :",x);
except ValueError:
       print("Oops!  That was no valid number.  Try again...")
