##Program to Accept 3 numbers from user and show max number


##Ask to Enter the No.



a=int(input("Enter number 1   :"));
b=int(input("Enter number 2    :"));
c=int(input("Enter number 3    :"));

myList=[a,b,c];

print("Max Value from myList",max(myList));
print("Min Value from myList",min(myList));
print("Sum of elements from myList",sum(myList));
print("Avg of elements from myList",(sum(myList)/len(myList)));
      

      

      


    

