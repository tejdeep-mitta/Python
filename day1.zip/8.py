##Program to Accept 3 numbers from user and show max number


##Ask to Enter the Number



a=int(input("Enter number 1   :"));
b=int(input("Enter number 2    :"));
c=int(input("Enter number 3    :"));

print(type(a),type(b),type(c));

if (a>b and a>c):
    print("Max Value :",a);
elif (b>a and b>c):
    print("Max Value :",b);
else :
    print("Max Value :",c);

    

