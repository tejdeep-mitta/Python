#This is my First Python Application
#This is my First Python Application
#This is my First Python Application

"""
This is multiline comment
"""


#print the welcome message 
a = "hello"
print(a)
