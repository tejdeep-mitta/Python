"""
Python Datatypes
==================
String
Number
List: Array of elements of similar data types and mutable
Tuple :Array of elements of similar data types and mutable
Set  :Unordered collection of unique values
Dictionay :
"""

employee={"id":101,"name":"Ram","salary":12000};

print("Employee :",employee);

print("Employee Keys   :",employee.keys());
print("Employee Values :",employee.values());


print("Employee Details");
print("=================");

for key in employee:
    print(key,employee.get(key));
          
          



  





