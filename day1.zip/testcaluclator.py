import calculator;


print("1000+20  :",calculator.add(1000,20));
print("1000-20  :",calculator.sub(1000,20));
print("1000*20  :",calculator.mul(1000,20));
print("1000/20  :",calculator.div(1000,20));
print("1000%20  :",calculator.mod(1000,20));
