#This is my First Python Application
#This is my First Python Application
#This is my First Python Application

"""
This is multiline comment
"""

str ="consider it done"
print(str+ '5' )
