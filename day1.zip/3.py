"""
Python Datatypes
==================
String
Number
List
Tuple
Set
Dictionay
"""

myList=["RAM","RAHIM","DAVID",100,200,300,500.55];


myList.append("Hello World");
myList.insert(2,"Mumbai");

print("My List :",myList);

for e in myList:
  print(e);

print("myList[0:3]",myList[0:3]);
print("myList[3:]",myList[3:]);
print("myList[2:3]",myList[2:3]);
print("myList[2:2]",myList[2:2]);



myList[2]="Ashutosh Mishra";
print("My List :",myList);






  





