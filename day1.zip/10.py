## define a calculateDiscount function


def calculateDiscount(amount):
    if(amount>=5000 and amount<=10000):

        print("Total Discount :",((amount*20)/100));
    elif(amount>10000):

        print("Total Discount :",((amount*50)/100));
    else:

        print("sorry You r not eligible for discount:");


amount=float(input("Enter amount "));
calculateDiscount(amount);




        

