"""
Python Datatypes
==================
String
Number
List
Tuple
Set  :Unordered collection of unique values
Dictionay :
"""


mySet={"RAM","RAHIM","DAVID","PRADEEP","RAM",11,22,11,22};

print("mySet :",mySet);

for element in mySet:
    print(element);


print("mySet[0]",mySet[0]);  


  





