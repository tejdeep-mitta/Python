## define a calculateDiscount function


def calculateIntrest(principal=40000,duration=1,roi=10):
     return (principal*roi*duration)/100;
   

print("Simple Intrest :",calculateIntrest());

print("Simple Intrest :",calculateIntrest(10000));

print("Simple Intrest :",calculateIntrest(10000,10));

print("Simple Intrest :",calculateIntrest(10000,20,5));

print("Simple Intrest :",calculateIntrest(duration=5,roi=50));











        

