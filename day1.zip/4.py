"""
Python Datatypes
==================
String
Number
List
Tuple
Set
Dictionay
"""

myTuple=("RAM","RAHIM","DAVID",100,200,300,500.55);

print("My Tuple :",myTuple);

for e in myTuple:
  print(e);

print("myTuple[0:3]",myTuple[0:3]);
print("myTuple[3:]",myTuple[3:]);
print("myTuple[2:3]",myTuple[2:3]);
print("myTuple[2:2]",myTuple[2:2]);
myTuple[2]="Ashutosh";  ##Tuples are immutable 
print("myTuple :",myTuple);




  





