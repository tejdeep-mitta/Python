##Program to Accept name from user and greet the user


##Ask to Enter the name 
name=input("Enter name :");

if name=='Andy':
    print("Hello ",name,"!!!","Welcome To syntel");
else:
   print("Invalid Name ");

input("Press any key to Exit");
