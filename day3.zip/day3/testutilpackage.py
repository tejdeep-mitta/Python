"""
import util.hello;
import util.welcome;
import util.greeting;

print("Hello     Module :",util.hello.hello());
print("Welcome   Module :",util.welcome.welcome());
print("GGreeting Module :",util.greeting.greet());

"""

from util import welcome;

print("Welcome   Module :",welcome.welcome());

