
def main():
    print("Mainfunction.....");

name="Pradeep Chinchole";
age=35;

def f1():
    a=100;
    b=200;
    print("Locals  :",locals());
    print("Globals :",globals());
    

f1();
