try:
    n=int(input("Enter number :"));
    print("You have entered :",n);
    print("Open the files....");
    a=100/n;
    print("a=",a)
except Exception as e:
    print(e); 
else:
    print("Close the files....");




