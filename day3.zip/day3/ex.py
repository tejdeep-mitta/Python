n=int(input("Enter number :"));
print("You have entered :",n);
print("Open the files....");
a=100/n;
print("a=",a)
print("Close the files....");
arr=["RAM","RAHIM","DAVID"];




